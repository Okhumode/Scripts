import base64
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad
import time

def encode_event(telegram_id: int, taps: int):
    current_time = int(time())
    print("Current Time (seconds):", current_time)

    combined_string = f"{telegram_id}|{taps}|{current_time}"
    print("Combined String:", combined_string)

    key_string = "tttttttttttttttttttttttttttttttt"
    iv_string = key_string[:16]
    print("Key String:", key_string)
    print("IV String:", iv_string)

    key_bytes = key_string.encode("utf-8")
    iv_bytes = iv_string.encode("utf-8")

    cipher = AES.new(key_bytes, AES.MODE_CBC, iv_bytes)
    encrypted_data = cipher.encrypt(pad(combined_string.encode("utf-8"), AES.block_size))

    encoded_data = base64.b64encode(encrypted_data).decode("utf-8")
    print("Encrypted Data (Base64):", encoded_data)

    final_encoded_data = base64.b64encode(encoded_data.encode("utf-8")).decode("utf-8")
    print("Final Encoded Data (Base64):", final_encoded_data)

    return final_encoded_data

encoded_game = encode_event(6822001415, 44)
print(encoded_game)
