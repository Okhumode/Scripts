import asyncio
from time import time
import random
from random import randint
from urllib.parse import unquote, quote, parse_qs

import aiohttp
from aiohttp_proxy import ProxyConnector
from better_proxy import Proxy
from pyrogram import Client
from pyrogram.errors import (
    Unauthorized,
    UserDeactivated,
    AuthKeyUnregistered,
    FloodWait,
)
from pyrogram.raw.functions.messages import RequestWebView

from bot.config import settings
from bot.utils import logger
from bot.exceptions import InvalidSession
from .headers import headers


class Tapper:
    def __init__(self, tg_client: Client):
        self.session_name = tg_client.name
        self.tg_client = tg_client
        self.sid = None
        self.access_token = None
        self.rev = 0
        self.player_data = {}
        self.game_username = None
        self.timestamp = int(time() * 1000)
        self.old_balance = None

    # Add time randomization - Because why not?
    async def randomized_sleep(self, min_seconds=3, max_seconds=6):
        delay = randint(min_seconds * 1000, max_seconds * 1000) / 1000
        logger.info(f"Sleep {delay}s")
        await asyncio.sleep(delay=delay)

    async def get_tg_web_data(self, proxy: str | None) -> str:
        if proxy:
            proxy = Proxy.from_str(proxy)
            proxy_dict = dict(
                scheme=proxy.protocol,
                hostname=proxy.host,
                port=proxy.port,
                username=proxy.login,
                password=proxy.password,
            )
        else:
            proxy_dict = None

        self.tg_client.proxy = proxy_dict

        try:
            with_tg = True

            if not self.tg_client.is_connected:
                with_tg = False
                try:
                    await self.tg_client.connect()
                except (Unauthorized, UserDeactivated, AuthKeyUnregistered):
                    raise InvalidSession(self.session_name)

            while True:
                try:
                    peer = await self.tg_client.resolve_peer("gemzcoin_bot")
                    break
                except FloodWait as fl:
                    fls = fl.value

                    logger.warning(f"{self.session_name} | FloodWait {fl}")
                    logger.info(f"{self.session_name} | Sleep {fls}s")

                    await asyncio.sleep(fls + 3)
            web_view = await self.tg_client.invoke(
                RequestWebView(
                    peer=peer,
                    bot=peer,
                    platform="weba",
                    from_bot_menu=False,
                    url="https://ff.notgemz.gemz.fun/",
                )
            )
            auth_url = web_view.url
            raw_tg_web_data = unquote(
                auth_url.split("tgWebAppData=", maxsplit=1)[1].split(
                    "&tgWebAppVersion", maxsplit=1
                )[0]
            )
            parsed_tg_web_data = parse_qs(raw_tg_web_data)
            # Rearrange the keys in the desired order
            ordered_keys = ["auth_date", "hash", "query_id", "user"]
            formatted_tg_web_data = "\n".join(
                [f"{key}={parsed_tg_web_data[key][0]}" for key in ordered_keys]
            )
            formatted_tg_web_data = formatted_tg_web_data.replace("%0A", "\\n")
            tg_web_data = quote(formatted_tg_web_data, safe="=&")
            tg_web_data = tg_web_data.replace("%0A", "\n")

            self.game_username = (await self.tg_client.get_me()).id

            if with_tg is False:
                await self.tg_client.disconnect()
            return tg_web_data

        except InvalidSession as error:
            raise error

        except Exception as error:
            logger.error(
                f"{self.session_name} | Unknown error during Authorization: {error}"
            )
            await asyncio.sleep(delay=3)

    def generate_id(self, random_func=None):
        if random_func is None:
            random_func = random.random
        return "".join(random.choices("abcdefghijklmnopqrstuvwxyz0123456789", k=9))

    async def login(
        self, http_client: aiohttp.ClientSession, tg_web_data: str
    ) -> tuple[dict, str]:
        try:
            self.sid = self.generate_id()
            payload = {
                "sid": self.sid,
                "id": str(self.game_username),
                "auth": tg_web_data,
            }
            response = await http_client.post(
                url="https://gemzcoin.us-east-1.replicant.gc-internal.net/gemzcoin/v2.48.3/loginOrCreate",
                json=payload,
            )
            response.raise_for_status()

            response_json = await response.json()
            self.player_data = response_json["data"]
            self.access_token = response_json["data"]["token"]
            main_rev = response_json["data"]["rev"]
            self.rev = main_rev - 1
            profile_data = response_json

            return profile_data, self.access_token, self.rev, self.player_data
        except Exception as error:
            logger.error(
                f"{self.session_name} | Unknown error while getting Access Token: {error}"
            )
            await asyncio.sleep(delay=3)

    async def apply_boost(
        self, http_client: aiohttp.ClientSession, boost_type: str
    ) -> bool:
        try:
            boost_name = boost_type
            increment_rev = self.rev + 1
            crqid = self.generate_id()
            payload = {
                "abTestsDynamicConfig": {
                    "0002_invite_drawer": {"active": True, "rollOut": 1}
                },
                "queue": [
                    {
                        "fn": "buyBuff",
                        "async": False,
                        "args": {"buff": boost_name},
                        "meta": {"now": self.timestamp},
                    }
                ],
                "rev": increment_rev,
                "requestedProfileIds": [],
                "consistentFetchIds": [],
                "sid": self.sid,
                "clientRandomSeed": 0,
                "crqid": crqid,
                "id": str(self.game_username),
                "auth": self.access_token,
            }

            response = await http_client.post(
                url="https://gemzcoin.us-east-1.replicant.gc-internal.net/gemzcoin/v2.48.3/replicate",
                json=payload,
            )
            response.raise_for_status()

            return True
        except Exception as error:
            logger.error(
                f"{self.session_name} | Unknown error when Apply {boost_type} Boost: {error}"
            )
            await asyncio.sleep(delay=3)

            return False

    async def upgrade_boost(
        self, http_client: aiohttp.ClientSession, boost_type: str
    ) -> bool:
        try:
            boost_name = boost_type
            increment_rev = self.rev + 1
            crqid = self.generate_id()
            payload = {
                "abTestsDynamicConfig": {
                    "0002_invite_drawer": {"active": True, "rollOut": 1}
                },
                "queue": [
                    {
                        "fn": "buyBooster",
                        "async": False,
                        "args": {"booster": boost_name},
                        "meta": {"now": self.timestamp},
                    }
                ],
                "rev": increment_rev,
                "requestedProfileIds": [],
                "consistentFetchIds": [],
                "sid": self.sid,
                "clientRandomSeed": 0,
                "crqid": crqid,
                "id": str(self.game_username),
                "auth": self.access_token,
            }

            response = await http_client.post(
                url="https://gemzcoin.us-east-1.replicant.gc-internal.net/gemzcoin/v2.48.3/replicate",
                json=payload,
            )
            response.raise_for_status()

            return True
        except Exception as error:
            logger.error(
                f"{self.session_name} | Unknown error when Upgrade {boost_type} Boost: {error}"
            )
            await asyncio.sleep(delay=3)

            return False

    # SKIPPING, SINCE THEY VERIFY IF YOU'VE DONE THE TASKS

    # async def claim_reward(self, http_client: aiohttp.ClientSession, task_id: str) -> bool:
    #     try:
    #         reward_name = task_id
    #         increment_rev = self.rev + 1
    #         crqid = self.generate_id()
    #         payload= {
    #                 "abTestsDynamicConfig": {
    #                     "0002_invite_drawer": {
    #                         "active": True,
    #                         "rollOut": 1
    #                     }
    #                 },
    #                 "queue": [{
    #                     "fn": "claimEarning",
    #                     "async": False,
    #                     "args": {
    #                          "earningKey": reward_name
    #                     },
    #                     "meta": {
    #                         "now": self.timestamp
    #                     }
    #                 }],
    #                 "rev": increment_rev,
    #                 "requestedProfileIds": [],
    #                 "consistentFetchIds": [],
    #                 "sid": self.sid,
    #                 "clientRandomSeed": 0,
    #                 "crqid": crqid,
    #                 "id": str(self.game_username),
    #                 "auth": self.access_token
    #             }

    #         await self.randomized_sleep()
    #         response = await http_client.post(url='https://gemzcoin.us-east-1.replicant.gc-internal.net/gemzcoin/v2.0.14/replicate',
    #                                           json=payload)
    #         response.raise_for_status()

    #         return True
    #     except Exception as error:
    #         logger.error(f"{self.session_name} | Unknown error when Claim {task_id} Reward: {error}")
    #         await asyncio.sleep(delay=3)

    #         return False

    async def send_taps(self, http_client: aiohttp.ClientSession, taps: int) -> dict:
        try:
            self.rev += 1  # Increment the rev value directly
            crqid = self.generate_id()
            payload = {
                "abTestsDynamicConfig": {
                    "0002_invite_drawer": {"active": True, "rollOut": 1}
                },
                "queue": [
                    {
                        "fn": "tap",
                        "async": False,
                        "meta": {"now": int(self.timestamp + i * 0.001)},
                    }
                    for i in range(taps)
                ],
                "rev": self.rev,
                "requestedProfileIds": [],
                "consistentFetchIds": [],
                "sid": self.sid,
                "clientRandomSeed": 0,
                "crqid": crqid,
                "id": str(self.game_username),
                "auth": self.access_token,
            }

            response = await http_client.post(
                url="https://gemzcoin.us-east-1.replicant.gc-internal.net/gemzcoin/v2.48.3/replicate",
                json=payload,
            )
            response.raise_for_status()

            response_json = await response.json()
            return response_json["data"]
        
        except Exception as error:
            logger.error(
                f"{self.session_name} | Unknown error while sending taps: {error}"
            )
            await asyncio.sleep(delay=3)

    async def check_proxy(
        self, http_client: aiohttp.ClientSession, proxy: Proxy
    ) -> None:
        try:
            response = await http_client.get(
                url="https://httpbin.org/ip", timeout=aiohttp.ClientTimeout(5)
            )
            ip = (await response.json()).get("origin")
            logger.info(f"{self.session_name} | Proxy IP: {ip}")
        except Exception as error:
            logger.error(f"{self.session_name} | Proxy: {proxy} | Error: {error}")

    async def run(self, proxy: str | None) -> None:
        access_token_created_time = 0
        turbo_time = 0
        active_turbo = False

        proxy_conn = ProxyConnector().from_url(proxy) if proxy else None

        async with aiohttp.ClientSession(
            headers=headers, connector=proxy_conn
        ) as http_client:
            if proxy:
                await self.check_proxy(http_client=http_client, proxy=proxy)

            tg_web_data = await self.get_tg_web_data(proxy=proxy)

            while True:
                try:
                    if time() - access_token_created_time >= 0:
                        profile_data, access_token, rev, player_data = await self.login(
                            http_client=http_client, tg_web_data=tg_web_data
                        )
                        access_token_created_time = time()

                        balance = player_data["state"]["balance"]
                        if self.old_balance is None:
                            self.old_balance = balance

                        json_data = {
                            "conf": {
                                "tap_levels": [
                                    {"limit": 1, "price": 2000},
                                    {"limit": 2, "price": 4000},
                                    {"limit": 3, "price": 8000},
                                    {"limit": 4, "price": 16000},
                                    {"limit": 5, "price": 32000},
                                    {"limit": 6, "price": 64000},
                                    {"limit": 7, "price": 128000},
                                    {"limit": 8, "price": 256000},
                                    {"limit": 9, "price": 512000},
                                    {"limit": 10, "price": 1024000},
                                ],
                                "energy_levels": [
                                    {"limit": 500, "price": 2000},
                                    {"limit": 1000, "price": 4000},
                                    {"limit": 1500, "price": 8000},
                                    {"limit": 2000, "price": 16000},
                                    {"limit": 2500, "price": 32000},
                                    {"limit": 3000, "price": 64000},
                                    {"limit": 3500, "price": 128000},
                                    {"limit": 4000, "price": 256000},
                                    {"limit": 4500, "price": 512000},
                                    {"limit": 5000, "price": 1024000},
                                ],
                                "recharge_levels": [
                                    {"limit": 1, "price": 2000},
                                    {"limit": 2, "price": 4000},
                                    {"limit": 3, "price": 8000},
                                ],
                            }
                        }

                        tap_prices = {
                            index + 1: data["price"]
                            for index, data in enumerate(
                                json_data["conf"]["tap_levels"]
                            )
                        }
                        energy_prices = {
                            index + 1: data["price"]
                            for index, data in enumerate(
                                json_data["conf"]["energy_levels"]
                            )
                        }
                        charge_prices = {
                            index + 1: data["price"]
                            for index, data in enumerate(
                                json_data["conf"]["recharge_levels"]
                            )
                        }

                        # Same reason, i gave above about claiming tasks
                        # claims = player_data["state"]["earnings"]
                        # if claims:
                        #     for task_id in claims:
                        #         await self.randomized_sleep()
                        #         logger.info(f"{self.session_name} | Sleep before claim <m>{task_id}</m> reward")
                        #         status = await self.claim_reward(http_client=http_client, task_id=task_id)
                        #         if status is True:
                        #             logger.success(f"{self.session_name} | Successfully claim <m>{task_id}</m> reward")
                        #             await asyncio.sleep(delay=1)

                    taps = randint(
                        a=settings.RANDOM_TAPS_COUNT[0], b=settings.RANDOM_TAPS_COUNT[1]
                    )

                    if active_turbo:
                        taps += settings.ADD_TAPS_ON_TURBO
                        if time() - turbo_time > 20:
                            active_turbo = False
                            turbo_time = 0

                    call_taps = await self.send_taps(http_client=http_client, taps=taps)
                    if not call_taps:
                        continue

                    old_balance = self.old_balance
                    available_energy = player_data["state"]["energy"]
                    new_balance = player_data["state"]["balance"]
                    calc_taps = abs(new_balance - old_balance)
                    balance = new_balance
                    total = player_data["state"]["score"]

                    turbo_boost_data = player_data["state"]["free_rocketman_used"]
                    turbo_boost_count = len(turbo_boost_data)
                    energy_boost_count = player_data["state"][
                        "free_energy_recharge_timestamp"
                    ]

                    next_tap_level = player_data["state"]["tap_level"] + 1
                    next_energy_level = player_data["state"]["energy_limit_level"] + 1
                    next_charge_level = (
                        player_data["state"]["energy_recharge_level"] + 1
                    )

                    logger.success(
                        f"{self.session_name} | Successfully tapped! | "
                        f"Balance: <c>{balance}</c> (<g>+{calc_taps}</g>) | Score: <e>{total}</e>"
                    )

                    if active_turbo is False:
                        if (
                            energy_boost_count == 0
                            and available_energy < settings.MIN_AVAILABLE_ENERGY
                            and settings.APPLY_DAILY_ENERGY is True
                        ):
                            await self.randomized_sleep()
                            status = await self.apply_boost(
                                http_client=http_client, boost_type="FullEnergy"
                            )
                            if status is True:
                                logger.success(
                                    f"{self.session_name} | Energy boost applied"
                                )
                                await asyncio.sleep(delay=1)
                            continue

                        if turbo_boost_count < 2 and settings.APPLY_DAILY_TURBO is True:
                            await self.randomized_sleep()
                            status = await self.apply_boost(
                                http_client=http_client, boost_type="Rocketman"
                            )
                            if status is True:
                                logger.success(
                                    f"{self.session_name} | Turbo boost applied"
                                )
                                await asyncio.sleep(delay=1)
                                active_turbo = True
                                turbo_time = time()
                            continue

                        if (
     