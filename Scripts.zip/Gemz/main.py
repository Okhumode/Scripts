import asyncio
from contextlib import suppress
from bot.utils.launcher import process
from bot.utils import logger

async def main():
    first_run = True
    while True:
        try:
            restart_time = 10 * 60 # 10 minutes in seconds
            if first_run:
                await process(timeout=restart_time) 
                first_run = False
            else:
                await process(action=2, timeout=restart_time)
        except asyncio.TimeoutError:
            logger.info(f"Process ran for {restart_time} seconds and timed out")
        except Exception as e:
            logger.error(f"An error occurred: {e}")
        logger.info("Restarting the process...")
        await asyncio.sleep(1)
        first_run = False

if __name__ == '__main__':
    with suppress(KeyboardInterrupt):
        asyncio.run(main())
