headers = {
    'x-app': 'tapswap_server',
    'x-cv': '631',
    'Content-Type': 'application/json',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 12; SM-G7810 Build/V417IR; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/91.0.4472.114 Safari/537.36',
    'x-touch': '1',
}