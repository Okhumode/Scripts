import asyncio
from random import randint
from datetime import datetime, timedelta
from urllib.parse import unquote
from typing import Any
import aiohttp
from aiohttp_proxy import ProxyConnector
from better_proxy import Proxy
from bot.core.headers import headers
from pyrogram import Client
from pyrogram.errors import Unauthorized, UserDeactivated, AuthKeyUnregistered
from pyrogram.raw.functions.messages import RequestWebView

from bot.config import settings
from bot.utils import logger
from bot.exceptions import InvalidSession


class Tapper:
    def __init__(self, tg_client: Client):
        self.session_name = tg_client.name
        self.tg_client = tg_client

    async def get_tg_web_data(self, proxy: str | None) -> str:
        if proxy:
            proxy = Proxy.from_str(proxy)
            proxy_dict = dict(
                scheme=proxy.protocol,
                hostname=proxy.host,
                port=proxy.port,
                username=proxy.login,
                password=proxy.password
            )
        else:
            proxy_dict = None

        self.tg_client.proxy = proxy_dict

        try:
            if not self.tg_client.is_connected:
                try:
                    await self.tg_client.connect()
                    rrs = False
                    msg = '/start nxiARh5OuKI9rIhL'
                    async for message in self.tg_client.get_chat_history('TimeFarmCryptoBot'):
                        if message.text == msg:
                            rrs = True
                            break

                    if not rrs:
                        await self.tg_client.send_message('TimeFarmCryptoBot', msg,
                                                          disable_notification=True)


                except (Unauthorized, UserDeactivated, AuthKeyUnregistered):
                    raise InvalidSession(self.session_name)

            web_view = await self.tg_client.invoke(RequestWebView(
                peer=await self.tg_client.resolve_peer('TimeFarmCryptoBot'),
                bot=await self.tg_client.resolve_peer('TimeFarmCryptoBot'),
                platform='android',
                from_bot_menu=False,
                url='https://tg-tap-miniapp.laborx.io'
            ))

            auth_url = web_view.url
            tg_web_data = unquote(
                string=auth_url.split('tgWebAppData=', maxsplit=1)[1].split('&tgWebAppVersion', maxsplit=1)[0])

            if self.tg_client.is_connected:
                await self.tg_client.disconnect()

            return tg_web_data

        except InvalidSession as error:
            raise error

        except Exception as error:
            logger.error(f"{self.session_name} | Unknown error during Authorization: {error}")
            await asyncio.sleep(delay=3)

    async def get_mining_data(self, http_client: aiohttp.ClientSession) -> dict[str]:
        try:
            response = await http_client.get('https://tg-bot-tap.laborx.io/api/v1/farming/info')
            response.raise_for_status()

            response_json = await response.json()

            return response_json
        except Exception as error:
            logger.error(f"{self.session_name} | Unknown error when getting Profile Data: {error}")
            await asyncio.sleep(delay=3)



    async def get_task(self, http_client: aiohttp.ClientSession) -> dict[str, Any]:
       base_url = "https://tg-bot-tap.laborx.io/api/v1"
       task_url = f"{base_url}/tasks"
       
       async with http_client.get(task_url) as response:
           response_data = await response.json()
 
       if not isinstance(response_data, list):
           logger.error("Response data is not a list")
           return {}
   
       for task in response_data:
           task_id = task.get("id")
           task_title = task.get("title")
           task_type = task.get("type")
   
           if task_type == "TELEGRAM":
               continue
   
           submission = task.get("submission")
           if submission:
               status = submission.get("status")
               if status == "CLAIMED":
                   logger.info(f"already completed task {task_title}")
                   continue
   
               if status == "COMPLETED":
                   url_claim = f"{base_url}/tasks/{task_id}/claims"
                   async with http_client.post(url_claim, json={}) as claim_response:
                       claim_response_text = await claim_response.text()
                       if claim_response_text.lower() == "ok":
                           logger.info(f"successfully claimed reward for {task_title}")
                           continue
   
           url_submit = f"{base_url}/tasks/{task_id}/submissions"
           async with http_client.post(url_submit, json={}) as submit_response:
               submit_response_text = await submit_response.text()
               if submit_response_text.lower() != "ok":
                   logger.info(f"failed to send submission for {task_title}")
                   continue
   
           async with http_client.get(f"{base_url}/tasks/{task_id}") as task_response:
               task_response_data = await task_response.json()
               submission = task_response_data.get("submission")
               if not submission:
                   logger.info(f"No submission found for task {task_id}")
                   continue
   
               status = submission.get("status")
               if status != "COMPLETED":
                   logger.info(f"task is not completed!")
                   continue
   
           url_claim = f"{base_url}/tasks/{task_id}/claims"
           async with http_client.post(url_claim, json={}) as final_claim_response:
               final_claim_response_text = await final_claim_response.text()
               if final_claim_response_text.lower() == "ok":
                   logger.info(f"successfully claimed reward for {task_title}")
   
       return {}
   


    async def send_claim(self, http_client: aiohttp.ClientSession) -> bool:
        try:
            response = await http_client.post('https://tg-bot-tap.laborx.io/api/v1/farming/finish', json={})
            response.raise_for_status()

            return True
        except Exception as error:
            logger.error(f"{self.session_name} | Unknown error while Claiming: {error}")
            await asyncio.sleep(delay=3)

            return False
        


    async def validate_init(self, http_client: aiohttp.ClientSession, tg_web_data: str) -> str:
        try:
            response = await http_client.post('https://tg-bot-tap.laborx.io/api/v1/auth/validate-init/v2',json={"initData":tg_web_data,"platform":"android"})
            response.raise_for_status()

            response_json = await response.json()
            login_response = response_json

            return login_response
        except Exception as error:
            logger.error(f"{self.session_name} | Unknown error while Claiming: {error}")
            await asyncio.sleep(delay=3)

            return False

    async def start_farming(self, http_client: aiohttp.ClientSession) -> bool:
        try:
            response = await http_client.post('https://tg-bot-tap.laborx.io/api/v1/farming/start', json={})
            response.raise_for_status()

            return True
        except Exception as error:
            logger.error(f"{self.session_name} | Unknown error when farming Started: {error}")
            await asyncio.sleep(delay=3)

            return False

    async def upgrade_level(self, http_client: aiohttp.ClientSession) -> dict[str]:
        try:
            response = await http_client.post(url=f'https://tg-bot-tap.laborx.io/api/v1/me/level/upgrade', json={})
            response.raise_for_status()

            response_json = await response.json()

            return response_json

        except Exception as error:
            logger.error(f"{self.session_name} | Unknown error while Upgrade Level: {error}")
            await asyncio.sleep(delay=3)    


    async def check_proxy(self, http_client: aiohttp.ClientSession, proxy: Proxy) -> None:
        try:
            response = await http_client.get(url='https://httpbin.org/ip', timeout=aiohttp.ClientTimeout(5))
            ip = (await response.json()).get('origin')
            logger.info(f"{self.session_name} | Proxy IP: {ip}")
        except Exception as error:
            logger.error(f"{self.session_name} | Proxy: {proxy} | Error: {error}")


    async def run(self, proxy: str | None) -> None:
        time_to_farming_end = 0

        proxy_conn = ProxyConnector().from_url(proxy) if proxy else None

        async with aiohttp.ClientSession(headers=headers, connector=proxy_conn) as http_client:
            if proxy:
                await self.check_proxy(http_client=http_client, proxy=proxy)

            while True:
                try:
                    tg_web_data = await self.get_tg_web_data(proxy=proxy)

                    http_client.headers["telegramRawData"] = tg_web_data
                    headers["telegramRawData"] = tg_web_data

                    login_response = await self.validate_init(http_client=http_client, tg_web_data=tg_web_data)
                    auth_token = login_response['token']
                    level = int(login_response['info']['level'])
                    levelDescriptions = login_response['levelDescriptions']
                    balance = login_response['balanceInfo']['balance']

                    http_client.headers["Authorization"] = f"Bearer {auth_token}"
                   
                    farming_data = await self.get_mining_data(http_client=http_client)
                    is_farming_started = farming_data['activeFarmingStartedAt']
                    farmingDurationInSec = farming_data['farmingDurationInSec']

                    if (settings.AUTO_UPGRADE_FARM is True and level < settings.MAX_UPGRADE_LEVEL): 
                       next_level = level + 1
                       max_level_bot = len(levelDescriptions) - 1
                       if next_level <= max_level_bot:
                           for level_data in levelDescriptions:
                               lvl_dt_num = int(level_data['level'])
                               if next_level == lvl_dt_num:
                                   lvl_price = int(level_data['price'])
                                   if lvl_price <= balance:
                                       logger.info(f"{self.session_name} | Sleep 5s before upgrade farming level to {next_level} lvl")
                                       await asyncio.sleep(delay=5)

                                       out_data = await self.upgrade_level(http_client=http_client)
                                       if out_data['balance']:
                                           logger.success(f"{self.session_name} | Farming level upgraded to {next_level} lvl | "
                                           f"Cost: <c>{out_data['balance']}</c> | "
                                           f"Speed: <g>x{level_data['farmMultiplicator']}</g>")
                                           
                                           await asyncio.sleep(delay=1)


                    # claim tasks
                    await self.get_task(http_client=http_client)

                    if is_farming_started is None:
                        rand_sleep_between_farming = randint(settings.SLEEP_BETWEEN_FARMING[0],
                                                             settings.SLEEP_BETWEEN_FARMING[1])
                        logger.info(f"{self.session_name} | Wait {rand_sleep_between_farming} seconds before farming starts")
                        await asyncio.sleep(delay=rand_sleep_between_farming)

                        status = await self.start_farming(http_client=http_client)
                        if status:
                            time_to_farming_end = farmingDurationInSec
                            logger.success(f"{self.session_name} | Successfully started farming")
                            logger.info(f"{self.session_name}  | Next claim in {time_to_farming_end} seconds")
                    else:
                        start_time = datetime.strptime(farming_data["activeFarmingStartedAt"], "%Y-%m-%dT%H:%M:%S.%fZ")
                        time_interval = timedelta(seconds=farmingDurationInSec)
                        current_time = datetime.utcnow()

                        # Check if user can claim
                        if current_time > start_time + time_interval:
                            rand_sleep_between_claim = randint(settings.SLEEP_BETWEEN_CLAIM[0],
                                                               settings.SLEEP_BETWEEN_CLAIM[1])
                            logger.info(f"{self.session_name} | Wait {rand_sleep_between_claim} seconds before claiming farming Rewards")
                            await asyncio.sleep(delay=rand_sleep_between_claim)

                            status = await self.send_claim(http_client=http_client)
                            if status:
                                farming_data = await self.get_mining_data(http_client=http_client)
                                logger.success(
                                    f"{self.session_name} | Successfully claimed  farming reward | Balance: <c>{farming_data['balance']}</c>")

                                rand_sleep_between_farming = randint(settings.SLEEP_BETWEEN_FARMING[0],
                                                                     settings.SLEEP_BETWEEN_FARMING[1])
                                logger.info(f"{self.session_name} | Wait {rand_sleep_between_farming} before farming starts")
                                await asyncio.sleep(delay=rand_sleep_between_farming)

                                status = await self.start_farming(http_client=http_client)
                                if status:
                                    time_to_farming_end = farmingDurationInSec
                                    logger.success(f"{self.session_name} | Successfully started farming")
                                    logger.info(f"{self.session_name} | Next claim in {time_to_farming_end} seconds")
                        else:
                            end_time = start_time + timedelta(seconds=farming_data["farmingDurationInSec"])
                            current_time = datetime.utcnow()
                            time_remaining = max(end_time - current_time, timedelta(seconds=0))
                            time_to_farming_end = int(time_remaining.total_seconds())
                            logger.info(
                                f"{self.session_name} | Farming is in progress | Wait {time_to_farming_end} seconds before farming ends")

                except InvalidSession as error:
                    raise error

                except Exception as error:
                    logger.error(f"{self.session_name} | Unknown error: {error}")
                    await asyncio.sleep(delay=3)

                else:
                    logger.info(f"{self.session_name} | Sleep {time_to_farming_end} seconds")
                    await asyncio.sleep(delay=time_to_farming_end)
                    # Additional sleep to ensure current time is is a litlle bit greater than end of farming time
                    await asyncio.sleep(delay=30)


async def run_tapper(tg_client: Client, proxy: str | None):
    try:
        await Tapper(tg_client=tg_client).run(proxy=proxy)
    except InvalidSession:
        logger.error(f"{tg_client.name} | Invalid Session")